box2d 2.4.1 - MIT license

Source: https://github.com/erincatto/box2d/releases/tag/v2.4.1

The src/CMakelists.txt file is a somewhat simplified version, easier to be
integrated to our course's CMake project format