#pragma once

#include "RectangleObjects.h"

class StaticObject : public RectangleObjects
{
public:
	using RectangleObjects::RectangleObjects;
};