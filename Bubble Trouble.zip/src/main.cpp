#include "Controller.h"
#include "SFML/Network.hpp"
#include <iostream>

int main()
{
	Controller gameController;
	gameController.play();

	return 0;
}